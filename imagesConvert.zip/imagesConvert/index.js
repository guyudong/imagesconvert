const express = require('express');  
const path = require('path');  
const app = express();  
  
// 设置静态文件目录为dist  
app.use(express.static(path.join(__dirname, './public/dist')));  
  
// 对于所有其他请求，你可以重定向到index.html（可选）  
app.get('*', (req, res) => {  
  res.sendFile(path.join(__dirname, './public/dist', 'index.html'));  
});  
  
const PORT = process.env.PORT || 8888;  
app.listen(PORT, () => {  
  console.log(`Server is running on port ${PORT}.`);  
});